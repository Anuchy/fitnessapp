import { makeStyles } from "@material-ui/core/styles";

export default makeStyles({
    
    appbar:{
        backgroundColor:'#262726'
    },
    typo:{
        backgroundColor:'#262726',
        textAlign:'center',
        fontFamily:'comic sans ms',
        fontWeight:'bold'
        
    },
    avtar:{
       height:'50px',
       width:'50px',
       
    }



})