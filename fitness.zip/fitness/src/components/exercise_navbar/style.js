import { makeStyles } from "@material-ui/core";

export default makeStyles({
    appbar:{
        
        backgroundColor:'whitesmoke',   
        
    }
    ,
    chip:{
        backgroundColor:'orange',
        color:'orange'
    }




})